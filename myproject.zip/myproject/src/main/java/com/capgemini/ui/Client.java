package com.capgemini.ui;

import java.math.BigDecimal;

import org.springframework.context.support.GenericXmlApplicationContext;

import com.capgemini.bean.Customer;
import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.exception.InvalidInputException;
import com.capgemini.service.CustomerService;
import com.capgemini.service.CustomerServiceImpl;

public class Client {
	
    public static void main(String[] args) throws InsufficientBalanceException, InvalidInputException {
  
		
		GenericXmlApplicationContext ctx= new GenericXmlApplicationContext("annotationconfig.xml");
		
    	CustomerService customerService= ctx.getBean("s",CustomerServiceImpl.class); 
    	Customer customer;
    	
    	
		customerService.createAccount("Nithej","9876500000",new BigDecimal(5000.00));
		System.out.println("Account is created");
		customerService.createAccount("Saibaba","9123456789",new BigDecimal(4000.00));
		System.out.println("Account is created");
		customerService.createAccount("Babasai","9874563210",new BigDecimal(3500.00));
		System.out.println("Account is created");
		
		
		customer = customerService.showBalance("9876500000");
		System.out.println("Balance= " + customer.getWallet().getBalance() );
		customer = customerService.showBalance("9123456789");
		System.out.println("Balance= " + customer.getWallet().getBalance() );
		customer = customerService.showBalance("9874563210");
		System.out.println("Balance= " + customer.getWallet().getBalance() );
		//customer = customerService.showBalance("9850276767");
		//System.out.println("Balance= " + customer.getWallet().getBalance() );
		ctx.close();
		
    }
    /*CustomerDAO customerDao= ctx.getBean("dao",WalletDAOImpl.class);

	
	Map<String, Customer> customerData = ctx.getBean(Map.class);

	customerDao.setCustomerData(customerData);*/
	
}