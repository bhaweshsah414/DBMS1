
package com.capgemini.service;

import com.capgemini.beans.Account;
import com.capgemini.exceptions.*;
import com.capgemini.repository.AccountRepository;

public class AccountServiceImpl implements AccountService{
    AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        super();
        this.accountRepository = accountRepository;
    }
    
    @Override
    public Account createAccount(int accountNumber, int amount) throws InsufficientOpeningBalanceException {
        
        if(amount < 500){
            throw new InsufficientOpeningBalanceException();
        }
        
        Account account = new Account();
        account.setAccountNumber(accountNumber); 
         account.setAmount(amount); 
         if(accountRepository.save(account))
         {
             return account;
         }
        
        
        return null;
    }
    
    

    public boolean checkAccountIsThere(int accountNumber) throws InvalidAccountNumberException {
	
    	
      Account accountFound= accountRepository.searchAccount(accountNumber);
       if (accountFound == null){
    	   return false; 
       }
       else {
    	   return true;
       }
       
       
    }
    
    public void isBalanceThere(int accountNumber) throws InsufficientOpeningBalanceException{
        
        
        
    }
    
        

    @Override
    public int depositAmount(int accountNumber, int amount) throws InvalidAccountNumberException{
        int updatedAmount = 0;
            if(checkAccountIsThere(accountNumber)){
                updatedAmount = accountRepository.updateBalance(amount);
                updatedAmount = amount + accountRepository.searchAccount(accountNumber).getAmount();
                
                
            }
            else{
                throw new InvalidAccountNumberException();
            }
    
           return updatedAmount;
    }   
      
   
    
      
    
  @Override
  public int  withDrawAmount(int accountNumber, int amount) throws InvalidAccountNumberException,InsufficientOpeningBalanceException{
      int updatedAmount = 0;
  
          if(checkAccountIsThere(accountNumber)){
          
          updatedAmount =  accountRepository.searchAccount(accountNumber).getAmount()- amount;
          if(updatedAmount < 0){
              throw new InvalidAccountNumberException();
          }
          
      }
      else{
          throw new InvalidAccountNumberException();
      }
  
      return updatedAmount;
  }
  

    
    
    
    }


